#!/usr/bin/env python3
"""Dummy WebSocket server for testing the NICU Monitor dashboard on a Mac or Linux.

Uses only Python's standard library (nothing to install). Same behaviour as
test-server.ps1, the Windows version:
  - vitals (HR, SpO2, RR, TcPCO2) once per second
  - ventilator values (PEEP, Ppeak, VTE, FiO2, mode...) once per breath (~40/min)
  - airway pressure / flow / volume waveforms at 50 Hz, in batches every 100 ms
  - every 60 s, a 20 s desaturation with bradycardia (fires the "SpO2 < 90" alert)

Usage:
  python3 test-server.py                     # ws://localhost:8765, JSON messages
  python3 test-server.py --port 9000 --style xlsx

Styles: json (default), xlsx (spreadsheet column names), text (key=value), csv.
"""
import argparse
import base64
import datetime
import hashlib
import json
import math
import random
import socket
import time

WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

# Simulated patient (same numbers as test-server.ps1)
BREATH_MS = 1500
INSP_MS = 400
PEEP = 6.0
PIP = 20.0
TIDAL_ML = 5.5
EXP_TAU_MS = 150.0
WAVE_STEP_MS = 20
WAVE_BATCH_MS = 100
EVENT_PERIOD_S, EVENT_START_S, EVENT_LENGTH_S = 60, 30, 20
CSV_HEADER = "time_ms,HR,SpO2,RR,TcPCO2,PEEP,PIP,Pmean,VTE,VTI,MV,f_total,FiO2,Mode,Cstat,Paw,Flow,Volume,Breath,Status"


def noise(size):
    return (random.random() * 2 - 1) * size


def iso(epoch_ms):
    dt = datetime.datetime.fromtimestamp(epoch_ms / 1000, tz=datetime.timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{epoch_ms % 1000:03d}Z"


def event_depth(t_ms):
    """0..1 depth of the current desaturation event (0 = none)."""
    t_s = t_ms / 1000
    p = (t_s - EVENT_START_S) % EVENT_PERIOD_S
    if t_s < EVENT_START_S or p >= EVENT_LENGTH_S:
        return 0.0
    return math.sin(math.pi * p / EVENT_LENGTH_S)


def vitals(t_ms):
    d = event_depth(t_ms)
    return {
        "HR": 150 + 6 * math.sin(t_ms / 20000) - 55 * d + noise(2),
        "SpO2": min(100, 94 - 12 * d + noise(1)),
        "RR": 42 + noise(3),
        "TcPCO2": 45 + 4 * d + noise(0.5),
    }


def vent(_t_ms):
    vte = TIDAL_ML + noise(0.2)
    ppeak = PIP + noise(0.3)
    return {
        "PEEP": PEEP, "PIP": ppeak, "Pmean": 10 + noise(0.3), "VTE": vte, "VTI": vte + 0.3,
        "MV": vte * 60000 / BREATH_MS / 1000, "fTotal": 60000 / BREATH_MS,
        "FiO2": 30, "Mode": "PSIMV", "Cstat": vte / (ppeak - PEEP),
    }


def wave(t_ms):
    in_breath = t_ms % BREATH_MS
    breath = t_ms // BREATH_MS + 1
    if in_breath < INSP_MS:
        paw = PEEP + (PIP - PEEP) * min(1.0, in_breath / 80)
        vol = TIDAL_ML * (1 - math.cos(math.pi * in_breath / INSP_MS)) / 2
        flow = TIDAL_ML * math.pi / (2 * INSP_MS) * math.sin(math.pi * in_breath / INSP_MS) * 60
        status = 1
    else:
        e = math.exp(-(in_breath - INSP_MS) / EXP_TAU_MS)
        paw = PEEP + (PIP - PEEP) * math.exp(-(in_breath - INSP_MS) / 40)
        vol = TIDAL_ML * e
        flow = -TIDAL_ML / EXP_TAU_MS * e * 60
        status = 0
    return {"Paw": paw + noise(0.1), "Flow": flow, "Volume": vol, "Breath": breath, "Status": status}


def r(x, digits=1):
    return round(x, digits) if digits else round(x)


# --- Messages in the chosen style ---
def format_vitals(style, t, ep, v):
    if style == "json":
        return json.dumps({"timestamp": ep, "hr": r(v["HR"], 0), "spo2": r(v["SpO2"], 0), "resp_rate": r(v["RR"], 0), "tcpco2": r(v["TcPCO2"])})
    if style == "xlsx":
        return json.dumps({"Time(ms)": t, "HR (0.2000000 Hz)": r(v["HR"], 0), "SpO2 (0.2000000 Hz)": r(v["SpO2"], 0), "RR (0.2000000 Hz)": r(v["RR"], 0), "TcPCO2 (mmHg)": r(v["TcPCO2"])})
    if style == "text":
        return f"time={iso(ep)}, HR={r(v['HR'], 0)}, SpO2={r(v['SpO2'], 0)}, RR={r(v['RR'], 0)}, TcPCO2={r(v['TcPCO2'])}"
    return f"{t},{r(v['HR'], 0)},{r(v['SpO2'], 0)},{r(v['RR'], 0)},{r(v['TcPCO2'])}" + "," * 15


def format_vent(style, t, ep, v):
    if style == "json":
        return json.dumps({"timestamp": ep, "ventilator": {"PEEP": r(v["PEEP"]), "PIP": r(v["PIP"]), "Pmean": r(v["Pmean"]), "VTE": r(v["VTE"]), "VTI": r(v["VTI"]), "MV": r(v["MV"], 2), "f_total": r(v["fTotal"], 0), "FiO2": r(v["FiO2"], 0), "Mode": v["Mode"], "Cstat": r(v["Cstat"], 2)}})
    if style == "xlsx":
        return json.dumps({"Time(ms)": t, "Peep (cmH2O)": r(v["PEEP"]), "P peak (cmH2O)": r(v["PIP"]), "P mean (cmH2O)": r(v["Pmean"]), "VTE (ml)": r(v["VTE"]), "VTI (ml)": r(v["VTI"]), "ExpMinVol (l/min)": r(v["MV"], 2), "f total (b/min)": r(v["fTotal"], 0), "Oxygen (%)": r(v["FiO2"], 0), "Mode": v["Mode"], "Cstat (ml/cmH2O)": r(v["Cstat"], 2)})
    if style == "text":
        return (f"time={iso(ep)}, PEEP={r(v['PEEP'])}, Ppeak={r(v['PIP'])}, Pmean={r(v['Pmean'])}, VTE={r(v['VTE'])}, VTI={r(v['VTI'])}, "
                f"MinVol={r(v['MV'], 2)}, fTotal={r(v['fTotal'], 0)}, FiO2={r(v['FiO2'], 0)}, Mode={v['Mode']}, Cstat={r(v['Cstat'], 2)}")
    return (f"{t},,,,,{r(v['PEEP'])},{r(v['PIP'])},{r(v['Pmean'])},{r(v['VTE'])},{r(v['VTI'])},{r(v['MV'], 2)},"
            f"{r(v['fTotal'], 0)},{r(v['FiO2'], 0)},{v['Mode']},{r(v['Cstat'], 2)}" + "," * 5)


def format_waves(style, samples):
    """One message holding several waveform samples: [(t_ms, epoch_ms, wave), ...]."""
    if style == "json":
        return json.dumps([{"timestamp": ep, "paw": r(w["Paw"], 2), "flow": r(w["Flow"], 3), "volume": r(w["Volume"], 2), "breath": w["Breath"], "status": w["Status"]} for t, ep, w in samples])
    if style == "xlsx":
        return json.dumps([{"Time(ms)": t, "Breath": w["Breath"], "Status": w["Status"], "Paw (cmH2O)": r(w["Paw"], 2), "Flow (l/min)": r(w["Flow"], 3), "Volume (ml)": r(w["Volume"], 2)} for t, ep, w in samples])
    if style == "text":
        return "\n".join(f"time={iso(ep)}, Paw={r(w['Paw'], 2)}, Flow={r(w['Flow'], 3)}, Volume={r(w['Volume'], 2)}, Breath={w['Breath']}, Status={w['Status']}" for t, ep, w in samples)
    return "\n".join(f"{t}" + "," * 15 + f"{r(w['Paw'], 2)},{r(w['Flow'], 3)},{r(w['Volume'], 2)},{w['Breath']},{w['Status']}" for t, ep, w in samples)


# --- Minimal WebSocket server (RFC 6455, server to client text frames) ---
def frame(opcode, payload):
    n = len(payload)
    if n < 126:
        header = bytes([0x80 | opcode, n])
    elif n < 65536:
        header = bytes([0x80 | opcode, 126]) + n.to_bytes(2, "big")
    else:
        header = bytes([0x80 | opcode, 127]) + n.to_bytes(8, "big")
    return header + payload


class Server:
    def __init__(self, port, style):
        self.port = port
        self.style = style
        self.clients = []
        self.sent = 0
        self.listeners = []
        for family, host in ((socket.AF_INET, "127.0.0.1"), (socket.AF_INET6, "::1")):
            try:
                s = socket.socket(family, socket.SOCK_STREAM)
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                s.bind((host, port))
                s.listen()
                s.setblocking(False)
                self.listeners.append(s)
            except OSError:
                if family == socket.AF_INET:
                    raise SystemExit(f"Could not listen on port {port} - it is probably in use. Try: python3 test-server.py --port 9000")

    def accept(self):
        for listener in self.listeners:
            while True:
                try:
                    conn, addr = listener.accept()
                except BlockingIOError:
                    break
                self.handshake(conn, addr)

    def handshake(self, conn, addr):
        conn.setblocking(True)
        conn.settimeout(2)
        try:
            request = b""
            while b"\r\n\r\n" not in request:
                chunk = conn.recv(8192)
                if not chunk:
                    break
                request += chunk
            key = None
            for line in request.decode("latin-1").split("\r\n"):
                if line.lower().startswith("sec-websocket-key:"):
                    key = line.split(":", 1)[1].strip()
            if not key:
                # Opened in a browser tab as a web page: explain instead of failing silently.
                body = f"NICU Monitor test server is running. Open index.html and connect to ws://localhost:{self.port}".encode()
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: %d\r\nConnection: close\r\n\r\n" % len(body) + body)
                conn.close()
                return
            accept = base64.b64encode(hashlib.sha1((key + WS_GUID).encode()).digest()).decode()
            conn.sendall(f"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: {accept}\r\n\r\n".encode())
            conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.clients.append(conn)
            print(f"  Dashboard connected ({addr[0]})", flush=True)
            if self.style == "csv":
                self.send_to(conn, CSV_HEADER)
        except OSError:
            conn.close()

    def drop(self, conn, why):
        if conn in self.clients:
            self.clients.remove(conn)
            conn.close()
            print(f"  Dashboard disconnected ({why})", flush=True)

    def send_to(self, conn, text):
        try:
            conn.sendall(frame(1, text.encode()))
        except OSError:
            self.drop(conn, "connection lost")

    def send_all(self, text):
        if not self.clients:
            return
        data = frame(1, text.encode())
        for conn in list(self.clients):
            try:
                conn.sendall(data)
            except OSError:
                self.drop(conn, "connection lost")
        self.sent += 1

    def check_incoming(self):
        """The dashboard only sends a close frame (or nothing); notice closed connections."""
        for conn in list(self.clients):
            try:
                conn.setblocking(False)
                data = conn.recv(4096)
                conn.setblocking(True)
                if not data:
                    self.drop(conn, "connection lost")
                elif data[0] & 0x0F == 8:
                    try:
                        conn.sendall(frame(8, b""))
                    except OSError:
                        pass
                    self.drop(conn, "closed by dashboard")
            except BlockingIOError:
                conn.setblocking(True)
            except OSError:
                self.drop(conn, "connection lost")

    def run(self):
        print()
        print("NICU Monitor test server")
        print(f"  Address : ws://localhost:{self.port}")
        print(f"  Format  : {self.style}")
        print(f"  In the dashboard, set the address to ws://localhost and the port to {self.port}, then click Connect.")
        print("  Press Ctrl+C to stop.")
        print(flush=True)
        start = time.monotonic()
        start_epoch = int(time.time() * 1000)
        next_vitals = next_breath = next_wave = 0
        next_batch, next_status = WAVE_BATCH_MS, 5000
        batch = []
        try:
            while True:
                self.accept()
                self.check_incoming()
                now = int((time.monotonic() - start) * 1000)
                while next_wave <= now:
                    batch.append((next_wave, start_epoch + next_wave, wave(next_wave)))
                    next_wave += WAVE_STEP_MS
                if now >= next_batch:
                    if batch:
                        self.send_all(format_waves(self.style, batch))
                    batch = []
                    next_batch += WAVE_BATCH_MS
                if now >= next_breath:
                    self.send_all(format_vent(self.style, next_breath, start_epoch + next_breath, vent(next_breath)))
                    next_breath += BREATH_MS
                if now >= next_vitals:
                    self.send_all(format_vitals(self.style, next_vitals, start_epoch + next_vitals, vitals(next_vitals)))
                    next_vitals += 1000
                if now >= next_status:
                    elapsed = time.strftime("%H:%M:%S", time.gmtime(now // 1000))
                    note = "  [simulated desaturation]" if event_depth(now) > 0 else ""
                    print(f"  {elapsed}  dashboards connected: {len(self.clients)}  messages sent: {self.sent}{note}", flush=True)
                    next_status += 5000
                time.sleep(0.01)
        except KeyboardInterrupt:
            pass
        finally:
            for conn in self.clients:
                conn.close()
            for listener in self.listeners:
                listener.close()
            print("Test server stopped.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dummy WebSocket server for the NICU Monitor dashboard.")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--style", choices=["json", "xlsx", "text", "csv"], default="json")
    args = parser.parse_args()
    Server(args.port, args.style).run()
