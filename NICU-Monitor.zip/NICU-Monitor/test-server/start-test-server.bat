@echo off
rem Double-click to start the NICU Monitor test server (uses PowerShell, built into Windows).
rem Optional, from a Command Prompt:  start-test-server.bat 9000 xlsx   (port, then style: json, xlsx, text or csv)
title NICU Monitor test server
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0test-server.ps1" %*
pause
