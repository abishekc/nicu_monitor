<#
.SYNOPSIS
  Dummy WebSocket server for testing the NICU Monitor dashboard. Nothing to install:
  uses only PowerShell, which comes with Windows.

.DESCRIPTION
  Sends simulated NICU data to every connected dashboard:
    - vitals (HR, SpO2, RR, TcPCO2) once per second
    - ventilator values (PEEP, Ppeak, VTE, FiO2, mode...) once per breath (~40/min)
    - airway pressure / flow / volume waveforms at 50 Hz, in batches every 100 ms
  Every 60 seconds there is a 20-second desaturation with bradycardia, so the
  dashboard's default "SpO2 < 90" alert fires.

  Only accepts connections from this computer (localhost), so Windows Firewall
  will not ask for permission.

.PARAMETER Port
  Port to listen on. Default 8765.

.PARAMETER Style
  Message format, to test the dashboard's field detection:
    json  JSON with everyday names and epoch timestamps (default)
    xlsx  JSON using the ventilator spreadsheet's column names and Time(ms)
    text  key=value text lines with ISO timestamps
    csv   CSV: a header line, then rows

.EXAMPLE
  .\test-server.ps1
  .\test-server.ps1 -Port 9000 -Style xlsx
#>
param(
  [int]$Port = 8765,
  [ValidateSet("json", "xlsx", "text", "csv")][string]$Style = "json"
)

$ErrorActionPreference = "Stop"
$WsGuid = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
$Utf8 = New-Object System.Text.UTF8Encoding($false)
$Inv = [System.Globalization.CultureInfo]::InvariantCulture
$Rng = New-Object System.Random

# Simulated patient
$BreathMs = 1500       # 40 breaths/min
$InspMs = 400          # inspiratory time
$Peep = 6.0
$Pip = 20.0
$TidalMl = 5.5
$ExpTauMs = 150.0
$WaveStepMs = 20       # 50 Hz
$WaveBatchMs = 100
$EventPeriodS = 60
$EventStartS = 30
$EventLengthS = 20
$CsvHeader = "time_ms,HR,SpO2,RR,TcPCO2,PEEP,PIP,Pmean,VTE,VTI,MV,f_total,FiO2,Mode,Cstat,Paw,Flow,Volume,Breath,Status"

function F([double]$x, [int]$digits = 1) { return [Math]::Round($x, $digits).ToString($Inv) }
function Noise([double]$size) { return ($Rng.NextDouble() * 2 - 1) * $size }
function Iso([long]$epochMs) {
  return [DateTimeOffset]::FromUnixTimeMilliseconds($epochMs).ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'", $Inv)
}
function Json-Str([string]$s) { return '"' + $s.Replace('\', '\\').Replace('"', '\"') + '"' }

# 0..1 depth of the current desaturation event (0 = none)
function Event-Depth([double]$tMs) {
  $p = ($tMs / 1000.0 - $EventStartS) % $EventPeriodS
  if ($tMs / 1000.0 -lt $EventStartS -or $p -ge $EventLengthS) { return 0.0 }
  return [Math]::Sin([Math]::PI * $p / $EventLengthS)
}

function Get-Vitals([double]$tMs) {
  $d = Event-Depth $tMs
  return @{
    HR     = 150 + 6 * [Math]::Sin($tMs / 20000.0) - 55 * $d + (Noise 2)
    SpO2   = [Math]::Min(100, 94 - 12 * $d + (Noise 1))
    RR     = 42 + (Noise 3)
    TcPCO2 = 45 + 4 * $d + (Noise 0.5)
  }
}

function Get-Vent([double]$tMs) {
  $vte = $TidalMl + (Noise 0.2)
  $ppeak = $Pip + (Noise 0.3)
  return @{
    PEEP = $Peep; PIP = $ppeak; Pmean = 10 + (Noise 0.3); VTE = $vte; VTI = $vte + 0.3
    MV = $vte * 60000.0 / $BreathMs / 1000.0; fTotal = 60000.0 / $BreathMs
    FiO2 = 30; Mode = "PSIMV"; Cstat = $vte / ($ppeak - $Peep)
  }
}

function Get-Wave([double]$tMs) {
  $inBreath = $tMs % $BreathMs
  $breath = [Math]::Floor($tMs / $BreathMs) + 1
  if ($inBreath -lt $InspMs) {
    $paw = $Peep + ($Pip - $Peep) * [Math]::Min(1.0, $inBreath / 80.0)
    $vol = $TidalMl * (1 - [Math]::Cos([Math]::PI * $inBreath / $InspMs)) / 2
    $flow = $TidalMl * [Math]::PI / (2 * $InspMs) * [Math]::Sin([Math]::PI * $inBreath / $InspMs) * 60
    $status = 1
  } else {
    $e = [Math]::Exp(-($inBreath - $InspMs) / $ExpTauMs)
    $paw = $Peep + ($Pip - $Peep) * [Math]::Exp(-($inBreath - $InspMs) / 40.0)
    $vol = $TidalMl * $e
    $flow = -$TidalMl / $ExpTauMs * $e * 60
    $status = 0
  }
  return @{ Paw = $paw + (Noise 0.1); Flow = $flow; Volume = $vol; Breath = $breath; Status = $status }
}

# --- Messages in the chosen style ---
function Format-Vitals([double]$tMs, [long]$epochMs, $v) {
  switch ($Style) {
    "json" { return "{`"timestamp`":$epochMs,`"hr`":$(F $v.HR 0),`"spo2`":$(F $v.SpO2 0),`"resp_rate`":$(F $v.RR 0),`"tcpco2`":$(F $v.TcPCO2 1)}" }
    "xlsx" { return "{`"Time(ms)`":$(F $tMs 0),`"HR (0.2000000 Hz)`":$(F $v.HR 0),`"SpO2 (0.2000000 Hz)`":$(F $v.SpO2 0),`"RR (0.2000000 Hz)`":$(F $v.RR 0),`"TcPCO2 (mmHg)`":$(F $v.TcPCO2 1)}" }
    "text" { return "time=$(Iso $epochMs), HR=$(F $v.HR 0), SpO2=$(F $v.SpO2 0), RR=$(F $v.RR 0), TcPCO2=$(F $v.TcPCO2 1)" }
    "csv"  { return "$(F $tMs 0),$(F $v.HR 0),$(F $v.SpO2 0),$(F $v.RR 0),$(F $v.TcPCO2 1),,,,,,,,,,,,,,," }
  }
}

function Format-Vent([double]$tMs, [long]$epochMs, $v) {
  switch ($Style) {
    "json" { return "{`"timestamp`":$epochMs,`"ventilator`":{`"PEEP`":$(F $v.PEEP),`"PIP`":$(F $v.PIP),`"Pmean`":$(F $v.Pmean),`"VTE`":$(F $v.VTE),`"VTI`":$(F $v.VTI),`"MV`":$(F $v.MV 2),`"f_total`":$(F $v.fTotal 0),`"FiO2`":$(F $v.FiO2 0),`"Mode`":$(Json-Str $v.Mode),`"Cstat`":$(F $v.Cstat 2)}}" }
    "xlsx" { return "{`"Time(ms)`":$(F $tMs 0),`"Peep (cmH2O)`":$(F $v.PEEP),`"P peak (cmH2O)`":$(F $v.PIP),`"P mean (cmH2O)`":$(F $v.Pmean),`"VTE (ml)`":$(F $v.VTE),`"VTI (ml)`":$(F $v.VTI),`"ExpMinVol (l/min)`":$(F $v.MV 2),`"f total (b/min)`":$(F $v.fTotal 0),`"Oxygen (%)`":$(F $v.FiO2 0),`"Mode`":$(Json-Str $v.Mode),`"Cstat (ml/cmH2O)`":$(F $v.Cstat 2)}" }
    "text" { return "time=$(Iso $epochMs), PEEP=$(F $v.PEEP), Ppeak=$(F $v.PIP), Pmean=$(F $v.Pmean), VTE=$(F $v.VTE), VTI=$(F $v.VTI), MinVol=$(F $v.MV 2), fTotal=$(F $v.fTotal 0), FiO2=$(F $v.FiO2 0), Mode=$($v.Mode), Cstat=$(F $v.Cstat 2)" }
    "csv"  { return "$(F $tMs 0),,,,,$(F $v.PEEP),$(F $v.PIP),$(F $v.Pmean),$(F $v.VTE),$(F $v.VTI),$(F $v.MV 2),$(F $v.fTotal 0),$(F $v.FiO2 0),$($v.Mode),$(F $v.Cstat 2),,,,," }
  }
}

# One message holding several waveform samples ($samples: list of @(tMs, epochMs, wave))
function Format-Waves($samples) {
  $parts = foreach ($s in $samples) {
    $t = $s[0]; $ep = $s[1]; $w = $s[2]
    switch ($Style) {
      "json" { "{`"timestamp`":$ep,`"paw`":$(F $w.Paw 2),`"flow`":$(F $w.Flow 3),`"volume`":$(F $w.Volume 2),`"breath`":$($w.Breath),`"status`":$($w.Status)}" }
      "xlsx" { "{`"Time(ms)`":$(F $t 0),`"Breath`":$($w.Breath),`"Status`":$($w.Status),`"Paw (cmH2O)`":$(F $w.Paw 2),`"Flow (l/min)`":$(F $w.Flow 3),`"Volume (ml)`":$(F $w.Volume 2)}" }
      "text" { "time=$(Iso $ep), Paw=$(F $w.Paw 2), Flow=$(F $w.Flow 3), Volume=$(F $w.Volume 2), Breath=$($w.Breath), Status=$($w.Status)" }
      "csv"  { "$(F $t 0),,,,,,,,,,,,,,,$(F $w.Paw 2),$(F $w.Flow 3),$(F $w.Volume 2),$($w.Breath),$($w.Status)" }
    }
  }
  if ($Style -eq "json" -or $Style -eq "xlsx") { return "[" + ($parts -join ",") + "]" }
  return ($parts -join "`n")
}

# --- Minimal WebSocket server (RFC 6455, server to client text frames) ---
$clients = New-Object System.Collections.Generic.List[object]

function New-Frame([byte]$opcode, [byte[]]$payload) {
  $len = $payload.Length
  if ($len -lt 126) {
    $header = [byte[]]((0x80 -bor $opcode), $len)
  } elseif ($len -lt 65536) {
    $header = [byte[]]((0x80 -bor $opcode), 126, ($len -shr 8), ($len -band 0xFF))
  } else {
    $header = New-Object byte[] 10
    $header[0] = 0x80 -bor $opcode
    $header[1] = 127
    for ($i = 0; $i -lt 8; $i++) { $header[9 - $i] = [byte](([long]$len -shr (8 * $i)) -band 0xFF) }
  }
  return , [byte[]]($header + $payload)
}

function Accept-Client($listener) {
  $tcp = $listener.AcceptTcpClient()
  $tcp.NoDelay = $true
  $stream = $tcp.GetStream()
  $stream.ReadTimeout = 2000
  $stream.WriteTimeout = 2000
  $buffer = New-Object byte[] 8192
  $request = ""
  try {
    while ($request.IndexOf("`r`n`r`n") -lt 0) {
      $n = $stream.Read($buffer, 0, $buffer.Length)
      if ($n -le 0) { break }
      $request += $Utf8.GetString($buffer, 0, $n)
    }
    $key = [regex]::Match($request, "Sec-WebSocket-Key:\s*(\S+)", "IgnoreCase")
    if (-not $key.Success) {
      # Opened in a browser tab as a web page: explain instead of failing silently.
      $body = "NICU Monitor test server is running. Open index.html and connect to ws://localhost:$Port"
      $reply = "HTTP/1.1 200 OK`r`nContent-Type: text/plain`r`nContent-Length: $($Utf8.GetByteCount($body))`r`nConnection: close`r`n`r`n$body"
      $bytes = $Utf8.GetBytes($reply)
      $stream.Write($bytes, 0, $bytes.Length)
      $tcp.Close()
      return $null
    }
    $sha1 = [System.Security.Cryptography.SHA1]::Create()
    $accept = [Convert]::ToBase64String($sha1.ComputeHash($Utf8.GetBytes($key.Groups[1].Value + $WsGuid)))
    $reply = "HTTP/1.1 101 Switching Protocols`r`nUpgrade: websocket`r`nConnection: Upgrade`r`nSec-WebSocket-Accept: $accept`r`n`r`n"
    $bytes = $Utf8.GetBytes($reply)
    $stream.Write($bytes, 0, $bytes.Length)
    $client = [pscustomobject]@{ Tcp = $tcp; Stream = $stream; Name = $tcp.Client.RemoteEndPoint.ToString() }
    Write-Host "  Dashboard connected ($($client.Name))" -ForegroundColor Green
    if ($Style -eq "csv") { Send-To $client $CsvHeader }
    return $client
  } catch {
    $tcp.Close()
    return $null
  }
}

function Remove-Client($client, [string]$why) {
  if ($clients.Remove($client)) {
    try { $client.Tcp.Close() } catch { }
    Write-Host "  Dashboard disconnected ($why)" -ForegroundColor Yellow
  }
}

function Send-To($client, [string]$text) {
  $frame = New-Frame 1 ($Utf8.GetBytes($text))
  try { $client.Stream.Write($frame, 0, $frame.Length); return $true }
  catch { Remove-Client $client "connection lost"; return $false }
}

$script:sent = 0
function Send-All([string]$text) {
  if ($clients.Count -eq 0) { return }
  $frame = New-Frame 1 ($Utf8.GetBytes($text))
  foreach ($c in $clients.ToArray()) {
    try { $c.Stream.Write($frame, 0, $frame.Length) } catch { Remove-Client $c "connection lost" }
  }
  $script:sent++
}

# The dashboard only sends a close frame (or nothing); notice closed connections.
function Check-Incoming {
  foreach ($c in $clients.ToArray()) {
    try {
      $socket = $c.Tcp.Client
      if ($c.Tcp.Available -gt 0) {
        $buf = New-Object byte[] $c.Tcp.Available
        [void]$c.Stream.Read($buf, 0, $buf.Length)
        if (($buf[0] -band 0x0F) -eq 8) {
          try { $c.Stream.Write([byte[]](0x88, 0), 0, 2) } catch { }
          Remove-Client $c "closed by dashboard"
        }
      } elseif ($socket.Poll(0, [System.Net.Sockets.SelectMode]::SelectRead)) {
        Remove-Client $c "connection lost"
      }
    } catch { Remove-Client $c "connection lost" }
  }
}

# --- Start listening (this computer only) ---
$listeners = @()
try {
  $l4 = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
  $l4.Start()
  $listeners += $l4
} catch {
  Write-Host "Could not listen on port $Port - it is probably in use by another program." -ForegroundColor Red
  Write-Host "Close that program or pick another port, e.g.:  .\test-server.ps1 -Port 9000"
  exit 1
}
try {
  # "localhost" can resolve to the IPv6 address ::1, so listen there too when available.
  $l6 = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::IPv6Loopback, $Port)
  $l6.Start()
  $listeners += $l6
} catch { }

Write-Host ""
Write-Host "NICU Monitor test server" -ForegroundColor Cyan
Write-Host "  Address : ws://localhost:$Port"
Write-Host "  Format  : $Style"
Write-Host "  In the dashboard, set the address to ws://localhost and the port to $Port, then click Connect."
Write-Host "  Press Ctrl+C to stop."
Write-Host ""

$clock = [System.Diagnostics.Stopwatch]::StartNew()
$startEpoch = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
$nextVitals = 0
$nextBreath = 0
$nextWave = 0
$nextBatch = $WaveBatchMs
$nextStatus = 5000
$batch = New-Object System.Collections.Generic.List[object]

try {
  while ($true) {
    foreach ($l in $listeners) {
      while ($l.Pending()) {
        $c = Accept-Client $l
        if ($c) { $clients.Add($c) }
      }
    }
    Check-Incoming

    $now = $clock.ElapsedMilliseconds
    while ($nextWave -le $now) {
      $batch.Add(@($nextWave, ($startEpoch + $nextWave), (Get-Wave $nextWave)))
      $nextWave += $WaveStepMs
    }
    if ($now -ge $nextBatch) {
      if ($batch.Count -gt 0) { Send-All (Format-Waves $batch) }
      $batch.Clear()
      $nextBatch += $WaveBatchMs
    }
    if ($now -ge $nextBreath) {
      Send-All (Format-Vent $nextBreath ($startEpoch + $nextBreath) (Get-Vent $nextBreath))
      $nextBreath += $BreathMs
    }
    if ($now -ge $nextVitals) {
      Send-All (Format-Vitals $nextVitals ($startEpoch + $nextVitals) (Get-Vitals $nextVitals))
      $nextVitals += 1000
    }
    if ($now -ge $nextStatus) {
      $elapsed = [TimeSpan]::FromMilliseconds($now).ToString("hh\:mm\:ss")
      $note = ""
      if ((Event-Depth $now) -gt 0) { $note = "  [simulated desaturation]" }
      Write-Host ("  {0}  dashboards connected: {1}  messages sent: {2}{3}" -f $elapsed, $clients.Count, $script:sent, $note)
      $nextStatus += 5000
    }
    Start-Sleep -Milliseconds 10
  }
} finally {
  foreach ($c in $clients.ToArray()) { try { $c.Tcp.Close() } catch { } }
  foreach ($l in $listeners) { $l.Stop() }
  Write-Host "Test server stopped."
}
