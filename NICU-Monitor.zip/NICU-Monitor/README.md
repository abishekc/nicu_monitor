# NICU Monitor: live data over WebSocket

Open `index.html` in Chrome, Edge or Firefox. You don't need to install anything or run a server. Keep the
`css/` and `js/` folders next to `index.html`, and if you received a .zip, extract it first.

## Connecting

1. Start the app that sends the data. It must run a **WebSocket server**, for example on port 8765.
2. In the dashboard header, check the address (`ws://localhost`) and the port, then click **Connect**.
3. The charts appear as soon as data arrives and keep scrolling forward.

- The dot shows the connection state: green means connected, amber means connecting or retrying, red means an error.
- If the connection drops, the dashboard keeps retrying every few seconds until you click **Disconnect**.
- The address, the port and whether you were connected are remembered on this computer. The next time you open
  the page, it reconnects by itself.
- **Jumping back in time** with the play bar stops the view from following new data. **Go live** jumps back to
  the newest data.
- **Upload New File** works while you're connected. Live data keeps being collected in the background, and
  **Show live data** switches back to it.
- Data is kept only while the page is open. Reloading the page or clicking **Connect** again starts a fresh recording.

Browsers can only *connect to* a WebSocket server; a web page cannot *be* one. So the sending app must listen
and this page connects to it. On the same laptop, use `ws://localhost` or `ws://127.0.0.1`. If `localhost`
doesn't connect, try `127.0.0.1`.

## Testing without the real device

The `test-server/` folder contains a dummy WebSocket server that sends simulated NICU data. Nothing needs installing.

- **Windows:** double-click `test-server/start-test-server.bat`. A console window opens and shows when a
  dashboard connects. Leave it open, open `index.html`, and click **Connect** (port 8765). Close the
  window or press Ctrl+C to stop. If Windows says "Windows protected your PC", click
  **More info → Run anyway**, since the file came from a zip.
- **Mac:** in Terminal, run `python3 test-server/test-server.py`, then open `index.html` and click **Connect**.

It simulates a ventilated neonate:
- Vitals once a second.
- Ventilator values once per breath, at 40 per minute.
- Pressure, flow and volume waveforms at 50 Hz.
- Every minute, starting 30 seconds in, a 20-second desaturation with bradycardia. SpO2 dips to about 82%
  and HR to about 95, so the default **SpO2 < 90** alert fires.

To try another port or check that a different message format is recognised, choose a style:

| Style | What the messages look like |
|---|---|
| `json` (default) | `{"timestamp": 1791904356495, "hr": 152, "spo2": 95, ...}` |
| `xlsx` | The ventilator spreadsheet's column names, e.g. `{"Time(ms)": 4000, "HR (0.2000000 Hz)": 152, ...}` |
| `text` | `time=2026-10-13T15:12:35.526Z, HR=152, SpO2=95, ...` |
| `csv` | A header line `time_ms,HR,SpO2,...`, then rows |

- **Windows**, from a Command Prompt in the `test-server` folder: `start-test-server.bat 9000 xlsx`
- **Mac:** `python3 test-server/test-server.py --port 9000 --style xlsx`

The test server only accepts connections from the same computer, so Windows Firewall won't ask about it.
If you open `http://localhost:8765` in a browser tab, it replies with a short "server is running" message.

## Message formats

The exact format doesn't matter much. Each message can be any of these:

| Format | Example |
|---|---|
| JSON object | `{"time": 1712345678901, "HR": 142, "SpO2": 95}` |
| JSON array of objects (several samples) | `[{"t": 0, "HR": 142}, {"t": 4000, "HR": 141}]` |
| Nested JSON | `{"timestamp": "...", "vitals": {"hr": 142, "spo2": 95}}` |
| List under `data` / `samples` / `readings`… | `{"timestamp": "...", "data": [{"Paw": 18}, {"Paw": 17}]}` |
| Name/value pairs | `[{"name": "HR", "value": 142}, {"name": "SpO2", "value": 95}]` |
| `key=value` or `key: value` text | `HR=142, SpO2=95` or `HR: 142 SpO2: 95` |
| CSV lines | a header line `time,HR,SpO2` first, then `0,142,95` |
| Newline-separated lines of any of the above | |

Values can be numbers or numeric strings. `null`, `""`, `"--"` and `"NaN"` mean "no reading".

### How fields are recognised

Field names are matched loosely. Case, spaces, `_`, `-` and units in brackets are ignored, as are common unit
endings such as `_bpm`, `_pct` and `_cmh2o`. So `HR`, `hr_bpm`, `Heart Rate` and `HR (0.2000000 Hz)` all mean
heart rate, and the column names from the ventilator's .xlsx export work as they are. Some examples:

- **Monitor:** HR (`hr`, `heart_rate`, `pulse`), SpO2 (`spo2`, `sat`), RR (`rr`, `resp_rate`), `hr_ecg`, `tcpco2`, IBP/NIBP
  systolic, diastolic and mean, and apnea duration in seconds (`apnea_duration`)
- **Ventilator:** `peep`, `ppeak` / `pip`, `pmean`, `pinsp`, `psupp`, `vte` / `vt`, `vti`, `expminvol` / `mv`,
  `f_total`, `fio2` / `oxygen`, `cstat` / `compliance`, `mode` (text)
- **Waveform:** `paw`, `flow`, `volume`, `paux`, `breath`, `status`

The full list is in the `FIELDS` table at the top of `js/live-stream.js`.

Click **Fields** in the header to see every field received, its latest value and how it's being used.
Unrecognised fields are shown in amber. Use the dropdown to choose what each one is, or **Don't use** to
ignore it. These choices are remembered on this computer and apply to new messages.

### Timestamps

The first field named `time`, `Time(ms)`, `t`, `ts`, `timestamp`, `elapsed` or similar is used as the sample
time:

- **Epoch milliseconds or seconds** (`1712345678901`, `1712345678`) or **ISO text** (`"2026-10-13T10:00:00Z"`):
  the first sample is 0:00.
- **Smaller numbers** are milliseconds since the recording started, like the .xlsx `Time(ms)` column. A field
  named `time (s)` or `seconds` is treated as seconds.
- **No timestamp field:** the time each message arrives is used.

Monitor or ventilator values sent in separate messages within 250 ms of each other are combined into one
reading, so the summary cards show them together.

## Limits

- Roughly the last 50,000 monitor readings, 20,000 ventilator readings and 300,000 waveform points are kept.
  That's about an hour of 80 Hz waveform. Older data is dropped as new data arrives.
- Charts update once per second.

## Files

- `index.html`: the page
- `js/live-stream.js`: the WebSocket listener (connection, field recognition, header controls)
- `css/live-stream.css`: styles for the header controls
- `test-server/`: the dummy WebSocket server (Windows: `start-test-server.bat` + `test-server.ps1`; Mac: `test-server.py`)
- `js/app.js`, `css/styles.css`, `css/fonts.css`: the dashboard itself. This is formatted build output; the
  changes for live streaming are marked `[live-stream]` in `app.js`.
