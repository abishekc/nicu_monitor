/*
 * NICU Monitor: live WebSocket listener.
 *
 * Connects to a WebSocket server (e.g. another app on this laptop at
 * ws://localhost:8765), works out which incoming fields are which vital /
 * ventilator / waveform values, and streams them into the dashboard.
 *
 * Talks to the dashboard through window.NICULive, which js/app.js calls:
 *   attach(api)              once, with { setLiveData, setCurrentTimeMs, resetData }
 *   onFileNameChange(name)   whenever the shown file / live source changes
 *   onTimeChange(ms)         whenever the playback time changes
 *
 * Accepted message formats are described in README.md.
 */
(function () {
  "use strict";

  const STORAGE_KEY = "nicu-live-stream";
  const DEFAULT_HOST = "ws://localhost";
  const DEFAULT_PORT = "8765";
  const FLUSH_MS = 1000; // how often new data is pushed to the charts
  const MERGE_WINDOW_MS = 250; // separate messages this close in time share one row
  const MAX_ROWS = { monitor: 50_000, vent: 20_000, waveform: 300_000 };
  const RECONNECT_MIN_MS = 1000;
  const RECONNECT_MAX_MS = 10_000;

  // ── Dashboard fields and the names they are recognised by ─────────────────
  // Names are compared after normalising: lower case, units in (...) / [...]
  // removed, and everything except letters and digits removed. So "HR",
  // "heart_rate", "Heart Rate" and "HR (0.2000000 Hz)" all match "hr"/"heartrate".
  const FIELDS = [
    { stream: "monitor", key: "hr", label: "HR (bpm)", names: ["hr", "heartrate", "pulse", "pulserate", "pr"] },
    { stream: "monitor", key: "spo2", label: "SpO2 (%)", names: ["spo2", "sao2", "o2sat", "sat", "saturation", "oxygensaturation", "spo2percent"] },
    { stream: "monitor", key: "rr", label: "RR (b/min)", names: ["rr", "resprate", "respiratoryrate", "respirationrate", "breathingrate"] },
    { stream: "monitor", key: "hrEcg", label: "HR ECG (bpm)", names: ["hrecg", "ecghr"] },
    { stream: "monitor", key: "resp", label: "RESP waveform", names: ["resp", "respwave"] },
    { stream: "monitor", key: "rrTime", label: "RR time", names: ["rrtime"] },
    { stream: "monitor", key: "tcpCO2", label: "TcPCO2 (mmHg)", names: ["tcpco2", "tcco2", "tco2", "transcutaneousco2"] },
    { stream: "monitor", key: "apneaDurationSec", label: "Apnea duration (s)", names: ["apneaduration", "apneadurations", "apneadurationsec", "apneasec"] },
    { stream: "monitor", key: "ibp2Sys", label: "IBP2 systolic", names: ["ibp2sys", "ibpsys", "abpsys", "artsys"] },
    { stream: "monitor", key: "ibp2Dia", label: "IBP2 diastolic", names: ["ibp2dia", "ibpdia", "abpdia", "artdia"] },
    { stream: "monitor", key: "ibp2Mean", label: "IBP2 mean", names: ["ibp2mean", "ibpmean", "abpmean", "artmean"] },
    { stream: "monitor", key: "nibpSys", label: "NIBP systolic", names: ["nibpsys", "bpsys", "systolic"] },
    { stream: "monitor", key: "nibpDia", label: "NIBP diastolic", names: ["nibpdia", "bpdia", "diastolic"] },
    { stream: "monitor", key: "nibpMean", label: "NIBP mean", names: ["nibpmean", "bpmean"] },

    { stream: "vent", key: "peep", label: "PEEP (cmH2O)", names: ["peep", "peepcpap", "cpap"] },
    { stream: "vent", key: "ppeak", label: "Ppeak (cmH2O)", names: ["ppeak", "pip", "peakpressure", "peakinspiratorypressure"] },
    { stream: "vent", key: "pmean", label: "Pmean (cmH2O)", names: ["pmean", "meanairwaypressure", "paw_mean", "pawmean"] },
    { stream: "vent", key: "pinsp", label: "Pinsp (cmH2O)", names: ["pinsp", "inspiratorypressure"] },
    { stream: "vent", key: "psupp", label: "Psupp (cmH2O)", names: ["psupp", "ps", "pressuresupport"] },
    { stream: "vent", key: "vte", label: "VTE (ml)", names: ["vte", "vt", "tidalvolume", "exhaledtidalvolume"] },
    { stream: "vent", key: "vti", label: "VTI (ml)", names: ["vti", "inspiredtidalvolume"] },
    { stream: "vent", key: "expMinVol", label: "ExpMinVol (l/min)", names: ["expminvol", "minvol", "minutevolume", "minutevent", "mv", "ve"] },
    { stream: "vent", key: "fTotal", label: "f total (b/min)", names: ["ftotal", "f", "ventrate", "totalrate", "totalbreathrate"] },
    { stream: "vent", key: "oxygen", label: "FiO2 / Oxygen (%)", names: ["oxygen", "fio2", "o2"] },
    { stream: "vent", key: "cstat", label: "Compliance (ml/cmH2O)", names: ["cstat", "compliance", "cdyn"] },
    { stream: "vent", key: "ets", label: "ETS (%)", names: ["ets"] },
    { stream: "vent", key: "ramp", label: "Ramp (ms)", names: ["ramp", "risetime"] },
    { stream: "vent", key: "mode", label: "Vent mode (text)", names: ["mode", "ventmode", "ventilationmode"], text: true },

    { stream: "waveform", key: "paw", label: "Paw waveform (cmH2O)", names: ["paw", "airwaypressure", "pressure"] },
    { stream: "waveform", key: "flow", label: "Flow waveform (l/min)", names: ["flow"] },
    { stream: "waveform", key: "volume", label: "Volume waveform (ml)", names: ["volume", "vol"] },
    { stream: "waveform", key: "paux", label: "Paux waveform (cmH2O)", names: ["paux"] },
    { stream: "waveform", key: "breath", label: "Breath number", names: ["breath", "breathnumber", "breathcount"] },
    { stream: "waveform", key: "status", label: "Breath status", names: ["status"] },
  ];
  const FIELD_BY_ID = new Map(FIELDS.map((f) => [`${f.stream}.${f.key}`, f]));
  const FIELD_BY_NAME = new Map();
  for (const f of FIELDS) for (const n of f.names) FIELD_BY_NAME.set(n.replace(/[^a-z0-9]/g, ""), f);

  // Field names treated as the sample's timestamp, in priority order.
  const TIME_NAMES = ["timems", "time", "t", "ts", "timestamp", "elapsedms", "elapsed", "times", "timesec", "seconds", "epochms", "epoch", "datetime", "date"];
  // Never data: the spreadsheet's "HH:MM:SS" column is an Excel day fraction.
  const IGNORED_NAMES = new Set(["hhmmss"]);
  const UNIT_SUFFIXES = ["cmh2o", "mmhg", "percent", "lmin", "bmin", "bpm", "pct", "mbar", "ml", "hz", "ms", "sec", "s"];

  const STREAM_LABELS = { monitor: "Monitor", vent: "Ventilator", waveform: "Waveform" };
  const EMPTY_ROW = {
    monitor: { hr: null, rr: null, ibp2Sys: null, ibp2Dia: null, ibp2Mean: null, nibpSys: null, nibpDia: null, nibpMean: null, spo2: null, resp: null, hrEcg: null, rrTime: null, tcpCO2: null, apneaDurationSec: null },
    vent: { peep: null, psupp: null, mode: null, ets: null, ramp: null, vti: null, vte: null, expMinVol: null, ppeak: null, pmean: null, pinsp: null, fTotal: null, oxygen: null, cstat: null },
    waveform: { breath: null, status: null, paw: null, flow: null, volume: null, paux: null },
  };

  // ── State ────────────────────────────────────────────────────────────────
  const settings = loadSettings();
  let api = null; // dashboard bridge from app.js
  let ws = null;
  let wantConnected = false; // user pressed Connect and not Disconnect
  let status = "idle"; // idle | connecting | connected | reconnecting | error
  let statusDetail = "";
  let reconnectTimer = null;
  let reconnectDelay = RECONNECT_MIN_MS;
  let liveName = null; // name shown in the header chip while live data is displayed

  let buffers = { monitor: [], vent: [], waveform: [] };
  let dirty = false;
  let displayLive = true; // false after the user uploads a file or clicks "Upload New File"
  let followLive = true; // keep playback at the newest sample
  let lastTimeWeSet = null;
  let shownFileName = null;
  let session = newSession();
  const keyInfo = new Map(); // raw field name -> { count, last, target, auto }
  let csvHeader = null;
  let messageTimes = [];
  let lastRawMessage = "";
  let lastError = "";
  let ui = null; // header controls, once mounted
  let fieldsChanged = true; // field table needs rebuilding
  let panelOpen = false;

  function newSession() {
    return { epochBase: null, wallBase: null, timeKey: null, timeUnit: "", messages: 0 };
  }

  function loadSettings() {
    const defaults = { host: DEFAULT_HOST, port: DEFAULT_PORT, autoConnect: false, mapping: {} };
    try {
      return { ...defaults, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") };
    } catch {
      return defaults;
    }
  }

  function saveSettings() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch {
      /* storage unavailable (private window etc.) - settings just won't persist */
    }
  }

  // ── Field recognition ────────────────────────────────────────────────────
  function normalizeKey(raw) {
    const units = [];
    // Remove units first so "HR (0.2000000 Hz)" isn't split at the decimal point,
    // then keep the last part of a nested key like "vitals.hr".
    let name = String(raw).replace(/[([{]([^)\]}]*)[)\]}]/g, (_, unit) => {
      units.push(unit.toLowerCase());
      return "";
    });
    name = name.split(".").pop().replace(/₂/g, "2");
    return { base: name.toLowerCase().replace(/[^a-z0-9]/g, ""), unit: units.join(" ") };
  }

  function autoTarget(rawKey) {
    const { base } = normalizeKey(rawKey);
    if (!base || IGNORED_NAMES.has(base)) return null;
    let field = FIELD_BY_NAME.get(base);
    // "hr_bpm", "spo2pct", "peep_cmh2o": retry with a trailing unit removed.
    for (let i = 0; !field && i < UNIT_SUFFIXES.length; i++) {
      const suffix = UNIT_SUFFIXES[i];
      if (base.length > suffix.length + 1 && base.endsWith(suffix)) {
        field = FIELD_BY_NAME.get(base.slice(0, -suffix.length));
      }
    }
    return field ? `${field.stream}.${field.key}` : null;
  }

  // Returns a field id ("monitor.hr"), "ignore", or null (not recognised).
  function targetFor(rawKey) {
    const manual = settings.mapping[rawKey];
    if (manual) return manual === "auto" ? autoTarget(rawKey) : manual;
    return autoTarget(rawKey);
  }

  function isTimeKey(rawKey) {
    return TIME_NAMES.includes(normalizeKey(rawKey).base);
  }

  function findTimeKey(record) {
    let best = null;
    let bestRank = Infinity;
    for (const key of Object.keys(record)) {
      const rank = TIME_NAMES.indexOf(normalizeKey(key).base);
      if (rank !== -1 && rank < bestRank && settings.mapping[key] !== "ignore") {
        best = key;
        bestRank = rank;
      }
    }
    return best;
  }

  const toNumber = (v) => {
    if (v === null || v === undefined || v === "" || v === "--" || v === "NaN") return null;
    if (typeof v === "boolean") return v ? 1 : 0;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };

  const toText = (v) => {
    if (v === null || v === undefined || v === "" || v === "--") return null;
    return String(v).trim() || null;
  };

  // Sample time in ms on the dashboard's clock (0 = start of this stream).
  function sampleTimeMs(record, receivedAt) {
    const key = findTimeKey(record);
    if (key !== null) {
      const unit = normalizeKey(key).unit;
      const base = normalizeKey(key).base;
      const raw = record[key];
      let ms = null;
      let isEpoch = false;
      const n = toNumber(raw);
      if (n !== null) {
        if (unit === "s" || unit === "sec" || base === "times" || base === "timesec" || base === "seconds") ms = n * 1000;
        else if (n > 1e11) (ms = n), (isEpoch = true); // epoch milliseconds
        else if (n > 1e9) (ms = n * 1000), (isEpoch = true); // epoch seconds
        else ms = n; // milliseconds since recording start, like the .xlsx "Time(ms)"
      } else if (typeof raw === "string") {
        const parsed = Date.parse(raw);
        if (!Number.isNaN(parsed)) (ms = parsed), (isEpoch = true);
      }
      if (ms !== null) {
        session.timeKey = key;
        session.timeUnit = isEpoch ? "clock time" : unit === "s" || ms !== n ? "seconds" : "ms";
        if (!isEpoch) return ms;
        if (session.epochBase === null) session.epochBase = ms;
        return ms - session.epochBase;
      }
    }
    session.timeKey = null;
    if (session.wallBase === null) session.wallBase = receivedAt;
    return receivedAt - session.wallBase;
  }

  // ── Message parsing: text -> flat { fieldName: value } records ────────────
  function parseMessage(text) {
    text = text.trim();
    if (!text) return [];
    if (text[0] === "{" || text[0] === "[") {
      try {
        return recordsFromJson(JSON.parse(text));
      } catch {
        /* not one JSON value - may be newline-delimited JSON or CSV below */
      }
    }
    return text.split(/\r?\n/).flatMap(parseLine);
  }

  function parseLine(line) {
    line = line.trim();
    if (!line) return [];
    if (line[0] === "{" || line[0] === "[") {
      try {
        return recordsFromJson(JSON.parse(line));
      } catch {
        /* fall through */
      }
    }
    // key=value or key: value pairs, e.g. "HR=140, SpO2=95" or "HR: 140 SpO2: 95".
    // (Not a CSV row that merely contains a clock time like 10:00:00.)
    if (line.includes("=") || /^[A-Za-z_][\w ./%₂()-]*:\s*\S/.test(line)) {
      const pairRe = /([A-Za-z_][\w ./%₂()-]*?)\s*[=:]\s*("[^"]*"|[^,;|\t ]+)/g;
      const record = {};
      let match;
      while ((match = pairRe.exec(line))) record[match[1].trim()] = match[2].replace(/^"|"$/g, "");
      if (Object.keys(record).length) return [record];
    }

    // CSV / tab-separated: a line with no numbers is taken as the header row.
    const cells = line.split(/[,\t;|]/).map((c) => c.trim().replace(/^"|"$/g, ""));
    if (cells.every((c) => toNumber(c) === null)) {
      csvHeader = cells;
      return [];
    }
    const names = csvHeader && csvHeader.length === cells.length ? csvHeader : cells.map((_, i) => `column ${i + 1}`);
    return [Object.fromEntries(names.map((name, i) => [name, cells[i]]))];
  }

  const NAME_KEYS = ["name", "label", "param", "parameter", "signal", "metric", "channel", "key", "code", "type"];
  const VALUE_KEYS = ["value", "val", "v", "reading", "measurement"];
  const META_KEYS = ["unit", "units", "uom"]; // describe a {name, value} item, not data
  const LIST_KEYS = ["data", "rows", "records", "samples", "readings", "values", "measurements", "items", "payload", "vitals"];

  function recordsFromJson(value, inherited = {}) {
    if (Array.isArray(value)) {
      // An array of {name, value} objects describes one sample; anything else is one record each.
      if (value.length && value.every(isNameValue)) return [{ ...inherited, ...mergeNameValues(value) }];
      return value.flatMap((item) => recordsFromJson(item, inherited));
    }
    if (!value || typeof value !== "object") return [];

    if (isNameValue(value)) return [{ ...inherited, ...mergeNameValues([value]) }];

    const scalars = { ...inherited };
    const nested = [];
    flatten(value, "", scalars, nested);
    // {"timestamp": ..., "data": [{...}, {...}]} - each list item is a record sharing the outer fields.
    if (nested.length) return nested.flatMap((list) => recordsFromJson(list, scalars));
    return [scalars];
  }

  function isNameValue(obj) {
    if (!obj || typeof obj !== "object" || Array.isArray(obj)) return false;
    const keys = Object.keys(obj).map((k) => k.toLowerCase());
    return keys.some((k) => NAME_KEYS.includes(k) && typeof obj[Object.keys(obj)[keys.indexOf(k)]] === "string") &&
      keys.some((k) => VALUE_KEYS.includes(k));
  }

  function mergeNameValues(items) {
    const record = {};
    for (const item of items) {
      let name = null;
      let val = null;
      for (const [k, v] of Object.entries(item)) {
        const lower = k.toLowerCase();
        if (name === null && NAME_KEYS.includes(lower) && typeof v === "string") name = v;
        else if (val === null && VALUE_KEYS.includes(lower)) val = v;
        else if (!META_KEYS.includes(lower) && (v === null || typeof v !== "object")) record[k] = v; // e.g. a per-item timestamp
      }
      if (name !== null) record[name] = val;
    }
    return record;
  }

  function flatten(obj, prefix, out, nestedLists) {
    for (const [k, v] of Object.entries(obj)) {
      const key = prefix ? `${prefix}.${k}` : k;
      if (Array.isArray(v)) {
        if (v.length && v.every(isNameValue)) Object.assign(out, mergeNameValues(v));
        else if (LIST_KEYS.includes(k.toLowerCase()) && v.some((item) => item && typeof item === "object")) nestedLists.push(v);
      } else if (v && typeof v === "object") {
        flatten(v, key, out, nestedLists);
      } else {
        out[key] = v;
      }
    }
  }

  // ── Records -> dashboard rows ────────────────────────────────────────────
  function ingestRecord(record, receivedAt) {
    const timeMs = sampleTimeMs(record, receivedAt);
    const perStream = { monitor: null, vent: null, waveform: null };

    for (const [rawKey, rawValue] of Object.entries(record)) {
      if (rawKey === session.timeKey) {
        noteKey(rawKey, rawValue, "time", false);
        continue;
      }
      const manual = settings.mapping[rawKey] && settings.mapping[rawKey] !== "auto";
      const target = targetFor(rawKey);
      noteKey(rawKey, rawValue, target, !manual);
      if (!target || target === "ignore") continue;
      const field = FIELD_BY_ID.get(target);
      if (!field) continue;
      const value = field.text ? toText(rawValue) : toNumber(rawValue);
      if (value === null) continue;
      (perStream[field.stream] ??= {})[field.key] = value;
    }

    for (const stream of ["monitor", "vent", "waveform"]) {
      if (perStream[stream]) addSample(stream, timeMs, perStream[stream]);
    }
  }

  function noteKey(rawKey, value, target, auto) {
    let info = keyInfo.get(rawKey);
    if (!info) {
      info = { count: 0, last: null, target, auto };
      keyInfo.set(rawKey, info);
      fieldsChanged = true;
    }
    if (info.target !== target || info.auto !== auto) {
      info.target = target;
      info.auto = auto;
      fieldsChanged = true;
    }
    info.count++;
    info.last = value;
  }

  function addSample(stream, timeMs, values) {
    const rows = buffers[stream];
    const lastIndex = rows.length - 1;
    const last = rows[lastIndex];
    // Signals sent in separate messages at (nearly) the same moment share a row,
    // as they do in the .xlsx export, so the summary cards show them together.
    const mergeWindow = stream === "waveform" ? 0 : MERGE_WINDOW_MS;
    if (last && Math.abs(last.timeMs - timeMs) <= mergeWindow && Object.keys(values).every((k) => last[k] === null)) {
      rows[lastIndex] = { ...last, ...values };
    } else {
      const row = { timeMs, ...EMPTY_ROW[stream], ...values };
      if (!last || timeMs >= last.timeMs) rows.push(row);
      else rows.splice(bisectRight(rows, timeMs), 0, row); // late / out-of-order sample
    }
    if (rows.length > MAX_ROWS[stream] * 1.1) rows.splice(0, rows.length - MAX_ROWS[stream]);
    dirty = true;
  }

  function bisectRight(rows, t) {
    let lo = 0;
    let hi = rows.length;
    while (lo < hi) {
      const mid = (lo + hi) >>> 1;
      if (rows[mid].timeMs <= t) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  }

  function maxTimeMs() {
    return Math.max(
      buffers.waveform.at(-1)?.timeMs ?? 0,
      buffers.monitor.at(-1)?.timeMs ?? 0,
      buffers.vent.at(-1)?.timeMs ?? 0,
    );
  }

  const hasData = () => buffers.monitor.length + buffers.vent.length + buffers.waveform.length > 0;

  // ── Pushing to the dashboard ─────────────────────────────────────────────
  function flush() {
    const now = Date.now();
    messageTimes = messageTimes.filter((t) => now - t < 5000);
    if (dirty && displayLive && api && hasData()) {
      dirty = false;
      const max = maxTimeMs();
      // New arrays each time so the dashboard's memoised calculations update.
      api.setLiveData(liveName, {
        monitor: buffers.monitor.slice(),
        vent: buffers.vent.slice(),
        waveform: buffers.waveform.slice(),
        maxTimeMs: max,
      });
      if (followLive) {
        lastTimeWeSet = max;
        api.setCurrentTimeMs(max);
      }
    }
    render();
  }

  function showLive() {
    displayLive = true;
    followLive = true;
    dirty = true;
    flush();
  }

  // ── WebSocket connection ─────────────────────────────────────────────────
  function buildUrl() {
    let host = settings.host.trim() || DEFAULT_HOST;
    if (!/^wss?:\/\//i.test(host)) host = `ws://${host.replace(/^\w+:\/\//, "")}`;
    const url = new URL(host);
    const port = String(settings.port).trim();
    if (port) {
      if (!/^\d{1,5}$/.test(port) || Number(port) > 65535) throw new Error("Port must be a number from 1 to 65535");
      url.port = port;
    }
    return url.toString().replace(/\/$/, "");
  }

  function connect(fresh) {
    clearTimeout(reconnectTimer);
    let url;
    try {
      url = buildUrl();
    } catch (err) {
      setStatus("error", err.message || "Invalid address");
      return;
    }
    if (fresh) {
      buffers = { monitor: [], vent: [], waveform: [] };
      session = newSession();
      csvHeader = null;
      keyInfo.clear();
      fieldsChanged = true;
      displayLive = true;
      followLive = true;
      reconnectDelay = RECONNECT_MIN_MS;
    }
    wantConnected = true;
    settings.autoConnect = true;
    saveSettings();
    liveName = `Live · ${url.replace(/^wss?:\/\//, "")}`;
    setStatus("connecting", url);

    let socket;
    try {
      socket = new WebSocket(url);
    } catch (err) {
      setStatus("error", err.message || "Could not open connection");
      scheduleReconnect();
      return;
    }
    socket.binaryType = "arraybuffer";
    ws = socket;
    socket.onopen = () => {
      if (ws !== socket) return;
      reconnectDelay = RECONNECT_MIN_MS;
      setStatus("connected", url);
    };
    socket.onmessage = (event) => {
      if (ws !== socket) return;
      const text = typeof event.data === "string" ? event.data : new TextDecoder().decode(event.data);
      handleMessage(text);
    };
    socket.onerror = () => {
      if (ws === socket) lastError = `Could not reach ${url}. Is the sending app running?`;
    };
    socket.onclose = () => {
      if (ws !== socket) return;
      ws = null;
      if (wantConnected) scheduleReconnect();
      else setStatus("idle", "");
    };
  }

  function scheduleReconnect() {
    clearTimeout(reconnectTimer);
    const seconds = Math.round(reconnectDelay / 1000);
    setStatus("reconnecting", `retrying in ${seconds}s`);
    reconnectTimer = setTimeout(() => connect(false), reconnectDelay);
    reconnectDelay = Math.min(reconnectDelay * 2, RECONNECT_MAX_MS);
  }

  function disconnect() {
    wantConnected = false;
    settings.autoConnect = false;
    saveSettings();
    clearTimeout(reconnectTimer);
    if (ws) {
      const socket = ws;
      ws = null;
      socket.close();
    }
    setStatus("idle", "");
  }

  function handleMessage(text) {
    const receivedAt = Date.now();
    session.messages++;
    messageTimes.push(receivedAt);
    lastRawMessage = text.length > 300 ? `${text.slice(0, 300)}…` : text;
    try {
      const records = parseMessage(text);
      for (const record of records) ingestRecord(record, receivedAt);
      lastError = "";
    } catch (err) {
      lastError = `Could not read a message: ${err.message}`;
    }
  }

  function setStatus(next, detail) {
    status = next;
    statusDetail = detail;
    if (next === "connected") lastError = "";
    render();
  }

  // ── Header UI ────────────────────────────────────────────────────────────
  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === "class") node.className = v;
      else if (k === "text") node.textContent = v;
      else if (k.startsWith("on")) node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v);
    }
    for (const child of children) node.append(child);
    return node;
  }

  function buildUi(slot) {
    const dot = el("span", { class: "nl-dot", "aria-hidden": "true" });
    const statusText = el("span", { class: "nl-status" });
    const host = el("input", { class: "nl-input nl-host", type: "text", spellcheck: "false", "aria-label": "WebSocket address", title: "WebSocket address, e.g. ws://localhost" });
    const port = el("input", { class: "nl-input nl-port", type: "text", inputmode: "numeric", "aria-label": "Port", title: "Port" });
    host.value = settings.host;
    port.value = settings.port;
    const saveInputs = () => {
      settings.host = host.value;
      settings.port = port.value;
      saveSettings();
    };
    const onEnter = (e) => e.key === "Enter" && !wantConnected && (saveInputs(), connect(true));
    host.addEventListener("change", saveInputs);
    port.addEventListener("change", saveInputs);
    host.addEventListener("keydown", onEnter);
    port.addEventListener("keydown", onEnter);

    const connectBtn = el("button", {
      class: "nl-btn nl-btn-primary",
      type: "button",
      onclick: () => (wantConnected ? disconnect() : (saveInputs(), connect(true))),
    });
    const goLiveBtn = el("button", {
      class: "nl-btn nl-btn-live",
      type: "button",
      title: "Jump back to the newest data and keep following it",
      onclick: () => {
        followLive = true;
        lastTimeWeSet = maxTimeMs();
        api?.setCurrentTimeMs(lastTimeWeSet);
        render();
      },
    }, ["Go live"]);
    const showLiveBtn = el("button", { class: "nl-btn nl-btn-live", type: "button", onclick: showLive }, ["Show live data"]);
    const fieldsBtn = el("button", {
      class: "nl-btn",
      type: "button",
      "aria-expanded": "false",
      onclick: () => {
        panelOpen = !panelOpen;
        fieldsChanged = true;
        render();
      },
    });

    const panelSummary = el("p", { class: "nl-panel-summary" });
    const tableBody = el("tbody");
    const rawPreview = el("code", { class: "nl-raw" });
    const panel = el("div", { class: "nl-panel", role: "dialog", "aria-label": "Incoming fields" }, [
      el("div", { class: "nl-panel-head" }, [
        el("strong", { text: "Incoming fields" }),
        el("button", { class: "nl-btn", type: "button", onclick: () => ((panelOpen = false), render()) }, ["Close"]),
      ]),
      panelSummary,
      el("div", { class: "nl-table-wrap" }, [
        el("table", { class: "nl-table" }, [
          el("thead", {}, [el("tr", {}, [el("th", { text: "Field received" }), el("th", { text: "Latest value" }), el("th", { text: "Shown as" })])]),
          tableBody,
        ]),
      ]),
      el("p", { class: "nl-hint", text: "Changes apply to new messages and are remembered on this computer." }),
      el("div", { class: "nl-raw-label", text: "Last message received" }),
      rawPreview,
    ]);

    const bar = el("div", { class: "nl-bar" }, [
      el("span", { class: "nl-state" }, [dot, statusText]),
      host,
      el("span", { class: "nl-colon", text: ":" }),
      port,
      connectBtn,
      fieldsBtn,
      goLiveBtn,
      showLiveBtn,
    ]);
    slot.replaceChildren(bar);
    // On <body>, not in the header, so it isn't drawn underneath the playback bar.
    document.body.append(panel);
    return { bar, dot, statusText, host, port, connectBtn, goLiveBtn, showLiveBtn, fieldsBtn, panel, panelSummary, tableBody, rawPreview, rows: new Map() };
  }

  function targetSelect(rawKey, info) {
    const select = el("select", { class: "nl-select", "aria-label": `Show ${rawKey} as` });
    const autoField = FIELD_BY_ID.get(autoTarget(rawKey));
    select.append(el("option", { value: "auto", text: autoField ? `Auto: ${autoField.label}` : "Auto: not recognised" }));
    select.append(el("option", { value: "ignore", text: "Don't use" }));
    for (const stream of ["monitor", "vent", "waveform"]) {
      const group = el("optgroup", { label: STREAM_LABELS[stream] });
      for (const f of FIELDS) if (f.stream === stream) group.append(el("option", { value: `${f.stream}.${f.key}`, text: f.label }));
      select.append(group);
    }
    select.value = settings.mapping[rawKey] || "auto";
    select.addEventListener("change", () => {
      if (select.value === "auto") delete settings.mapping[rawKey];
      else settings.mapping[rawKey] = select.value;
      saveSettings();
      info.target = targetFor(rawKey);
      info.auto = !settings.mapping[rawKey];
      fieldsChanged = true;
      render();
    });
    return select;
  }

  function render() {
    if (!ui) return;
    const connected = status === "connected";
    ui.dot.dataset.state = status;
    const rate = messageTimes.length / 5;
    const labels = {
      idle: hasData() ? "Disconnected" : "Not connected",
      connecting: "Connecting…",
      connected: session.messages ? `Live · ${rate < 10 ? rate.toFixed(1) : Math.round(rate)} msg/s` : "Connected · waiting for data",
      reconnecting: `Not reachable · ${statusDetail}`,
      error: statusDetail,
    };
    ui.statusText.textContent = labels[status];
    ui.bar.title = lastError || (connected ? statusDetail : "");
    ui.bar.dataset.error = lastError && status !== "connected" ? "true" : "false";
    ui.connectBtn.textContent = wantConnected ? "Disconnect" : "Connect";
    ui.host.disabled = wantConnected;
    ui.port.disabled = wantConnected;

    const live = displayLive && shownFileName === liveName && hasData();
    ui.goLiveBtn.hidden = !(live && !followLive);
    ui.showLiveBtn.hidden = displayLive || !hasData();

    const fields = [...keyInfo.values()];
    const used = fields.filter((f) => f.target && f.target !== "ignore" && f.target !== "time").length;
    const unknown = fields.filter((f) => !f.target).length;
    ui.fieldsBtn.hidden = keyInfo.size === 0;
    ui.fieldsBtn.textContent = unknown ? `Fields · ${unknown} unrecognised` : `Fields · ${used} in use`;
    ui.fieldsBtn.dataset.warn = unknown ? "true" : "false";
    ui.fieldsBtn.setAttribute("aria-expanded", String(panelOpen));
    ui.panel.hidden = !panelOpen;
    if (panelOpen) {
      ui.panel.style.top = `${ui.bar.closest("header")?.getBoundingClientRect().bottom ?? 60}px`;
      renderPanel();
    }
  }

  function renderPanel() {
    const timeText = session.timeKey
      ? `Time is read from "${session.timeKey}" (${session.timeUnit}).`
      : "No timestamp field found, so time is when each message arrived.";
    ui.panelSummary.textContent = `${session.messages.toLocaleString()} messages received. ${timeText}`;
    ui.rawPreview.textContent = lastRawMessage || "Nothing received yet.";

    if (fieldsChanged) {
      fieldsChanged = false;
      ui.tableBody.replaceChildren();
      ui.rows.clear();
      const sorted = [...keyInfo.entries()].sort(([, a], [, b]) => rank(a) - rank(b));
      for (const [rawKey, info] of sorted) {
        const valueCell = el("td", { class: "nl-value" });
        const targetCell = el("td");
        if (info.target === "time") targetCell.append(el("span", { class: "nl-tag", text: "Timestamp" }));
        else targetCell.append(targetSelect(rawKey, info));
        const row = el("tr", { "data-unknown": String(!info.target) }, [el("td", { class: "nl-key", text: rawKey }), valueCell, targetCell]);
        ui.tableBody.append(row);
        ui.rows.set(rawKey, valueCell);
      }
    }
    for (const [rawKey, cell] of ui.rows) {
      const v = keyInfo.get(rawKey)?.last;
      cell.textContent = v === null || v === undefined ? "—" : String(v).slice(0, 40);
    }
  }

  // Unrecognised fields first, then the timestamp, then the rest.
  const rank = (info) => (!info.target ? 0 : info.target === "time" ? 1 : 2);

  function mount() {
    const slot = document.getElementById("live-stream-slot");
    if (!slot) {
      requestAnimationFrame(mount);
      return;
    }
    ui = buildUi(slot);
    render();
  }

  // ── Bridge used by js/app.js ─────────────────────────────────────────────
  window.NICULive = {
    attach(dashboardApi) {
      api = dashboardApi;
      mount();
      if (settings.autoConnect) connect(true);
    },
    onFileNameChange(name) {
      const previous = shownFileName;
      shownFileName = name;
      // The user uploaded a file or clicked "Upload New File" while live: stop
      // replacing what they're looking at. Data keeps arriving; "Show live data" returns.
      if (name !== liveName && (name !== null || previous === liveName)) displayLive = false;
      render();
    },
    onTimeChange(ms) {
      if (shownFileName !== liveName) return;
      if (ms === lastTimeWeSet) return;
      // Scrubbing or replaying stops following; reaching the newest sample resumes it.
      followLive = ms >= maxTimeMs();
      render();
    },
  };

  setInterval(flush, FLUSH_MS);
})();
